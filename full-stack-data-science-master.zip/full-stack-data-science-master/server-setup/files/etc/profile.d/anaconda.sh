export PATH=/usr/local/anaconda3/bin:$PATH
