Scripts for launching and provisioning servers for the course.

