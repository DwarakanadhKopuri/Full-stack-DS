
def square(n):
    """Computes square of a numbers.
    """
    return n*n


def cube(n):
    """Computes cube of a numbers.
    """
    return n*n*n
